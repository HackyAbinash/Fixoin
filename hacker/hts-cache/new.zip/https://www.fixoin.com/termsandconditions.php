<!DOCTYPE html>
<html>

<head>
	<title>FiXOIN SERVICE PORTAL</title>

  <link rel="icon" href="images/x.ico" sizes="100x200" type="image/ico">
	<link rel="stylesheet" href="css/style.css" type="text/css">
  <link rel="stylesheet" href="nav/css/styles.css" type="text/css">
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="font/css/font-awesome.min.css" type="text/css">
	

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css" type="text/css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>

<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<style type="text/css">
.online-shop {
  animation: blinker 1s linear infinite;
}

@keyframes blinker {  
  20% { opacity: 0; }
}
.online-shop:hover {
  animation:none;
}
  </style>
</head>

<body style="background-color:  #F5FAFF";>
    <div class="row">
      <div class="col-md-1">
      </div>
      <div class="col-md-3">
        <img src="images/FIXOIN.png">
      </div>
      <div class="col-md-4">
        <h1 align="center" style="font-family:colonna MT";><font color="black">SERVICE PORTAL</font></h1>
        <h4 align="center">(Door Step Maintenance Service)</h4>
      </div>
      <div class="col-md-3">
        <h4 class="zyx" align="right"><font color="green"><span><i class="fa fa-phone fa-1x"></i></span></font> +91-9439-48-9095</h4>
         <h4 align="right" class="online-shop">
        <a style="color:#FF0000;" href="http://www.fixoin.in"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Online Store</a>
         </h4>


        <p align="right">
          <a href="http://facebook.com"><img src="images/facebook.png" height="20px" width="20px"></a>
          <a href="http://google.com"><img src="images/google.png" height="20px" width="20px"></a>
          <a href="http://twitter.com"><img src="images/twitter.png" height="20px" width="20px"></a>
          <a href="http://linkedin.com"><img src="images/linkedin.jpg" height="20px" width="20px"></a>
          <a href="http://youtube.com"><img src="images/youtube.png" height="20px" width="20px"></a>
        </p>
      </div>
      <div class="col-md-1">
      </div>
    </div>
   
<div class="hbgh">
<div class="container">
<header id="header">
  <div class="row t-container">
    <div class="span9">
      <nav id="nav" role="navigation">
        <a href="#nav" title="Show navigation">Show navigation</a>
        <a href="#" title="Hide navigation">Hide navigation</a>
          <ul class="clearfix">
            <li><a href="index.php" title="">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="#"><span>Track</span></a>
            <ul> <!-- Submenu -->
              <li><a href="track.php">Ticket No.</a></li>
              <li><a href="searchmob.php">Mobile No.</a></li>   
            </ul> <!-- End Submenu -->      
            </li>                
            <li><a href="http://www.fixoin.in">Online Store</a></li>
            <li><a href="#"><span>Company</span></a>
            <ul> <!-- Submenu -->
              <li><a href="about.php">About</a></li>
              <li><a href="branches.php">Branches</a></li>
              <li><a href="termsandconditions.php">T & C</a></li>
              <li><a href="contact.php">Contact</a></li> 
            </ul>
          </li>
          </ul>
      </nav>
    </div> 
  </div> 
</header>
</div>
</div>
<br/>
<div class="container">
<div class="ww">
  <h4 align="center" style="background-color:#E8DAEF;">Terms & Conditions for Customer</h4>
            <h4 align="left">Time :-</h4>
                    <ul>
                <li> If customer registered the complain after 6 PM , then customer will get service in next day .</li>
                <li>Contact Person must stay between the Repairing Time Because Fixoin has not any rights to Enter Customer house without contact person.</li>
                <li>Customer has to stay at time , when our Technical person will reach in customer location.</li>
        </ul>
   <h4>Charges :-</h4>
        <ul>
            <li>Customer has to give the charges according to the work done</li>
            <li>Customer must take money receipt from our Technical person.</li>
        </ul>
    <h4>Feedback :-</h4>
        <ul>
            <li>Customer Feedback is valuable for Fixoin to know customer satisfied or not.</li>
            <li>If customer not satisfied the work ,our Technical Team bound to give service again which is free of cost(Spare parts is chargeable).</li>
        </ul>
        </div>
        <div class="ww">
    <h4 align="center" style="background-color:#E8DAEF;">Terms & Conditions For Service Provider</h4>
        <h4>Role :-</h4>
        <ul>
            <li>Service Provider(own /Dealer/Technical Team) be ready always to go customer location.</li>
            <li>After taking complain Details from Fixoin ,Technical Team bound to call the customer and reconform the Complain details .</li>
            <li>After conforming our Technical team reach to customer location as soon as possible.</li>
        </ul>
        <h4>Time :-</h4>
        <ul>
            <li>Technical Team will give services between (9:00 AM TO 6:00 PM).</li>
        </ul>
        <h4>Charges :-</h4>
        <ul>
            <li>Charges should follow by Declared by Fixoin which is mention in charge List.</li>
            <li>Technical person has not any rights to take extra money/Tip from customer.</li>
        </ul>
        </div>
        <div class="ww">
    <h4 align="center" style="background-color:#E8DAEF">Terms & Conditions For Fixoin</h4>
        <h4>Role :-</h4>
        <ul>
            <li>Customer Care person Pull out Customer Complain in Every Moment from Webportal.</li>
            <li>Receive customer complain via offline(call, sms, what's app,..etc) and Registered in offline portal.</li>
            <li>After that send the complaint details to our Technical Team.</li>
            <li>Follow up accordingly till resolved the issue.</li>
        </ul>
        <h4>Time :-</h4>
        <ul>
            <li>Fixoin working Time is 9:00 AM to 6:00 PM.</li>
            <li>Within 1 hour our Technical Team will reach customer Location (depends on distance).</li>
            <li>If customer is registered the complain after 6:00 PM then customer will get service in next day morning.</li>
            <li>Customer will be not getting service ,if something is going wrong in city/location (Like:- Strike, Rathayatra crowed, durgapuja crowed time...etc)</li>
        </ul>
        <h4>Charges :-</h4>
        <ul>
            <li>Charges is depends on work .</li>
            <li>We should follow the charge List made by Fixoin.</li>
            <li>If Our Technical Team reach customer location after conforming customer but at that time customer don't want service from us then customer bound to pay Transport Charges(100 Rupees).</li>
        </ul>
        </div>

    </p>
    </div>


<h4 align="center">&#169 2018. FIXOIN . All Right Reserved. | Powered by <a href="www.alakainfotech.com">ALAKA INFOTECH.</a></h4>



<script type="text/javascript">
  document.oncontextmenu = document.body.oncontextmenu = function() {return false;}
</script>

</body>
</html>