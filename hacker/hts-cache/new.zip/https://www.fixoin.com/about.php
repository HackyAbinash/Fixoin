<!DOCTYPE html>
<html>
<head>
  <title>FiXOIN SERVICE PORTAL</title>

  <link rel="icon" href="images/x.ico" sizes="100x200" type="image/ico">
  <link rel="stylesheet" href="css/style.css" type="text/css">
  <link rel="stylesheet" href="nav/css/styles.css" type="text/css">
  <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="font/css/font-awesome.min.css" type="text/css">
  

<!-- Optional theme -->
<link rel="stylesheet" href="css/bootstrap-theme.min.css" type="text/css">

<!-- Latest compiled and minified JavaScript -->
<script src="js/bootstrap.min.js"></script>

<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="HandheldFriendly" content="true">
<style type="text/css">
.online-shop {
  animation: blinker 1s linear infinite;
}

@keyframes blinker {  
  20% { opacity: 0; }
}
.online-shop:hover {
  animation:none;
}
#sname h4{text-decoration: underline;} 
#sname{background-color: #E0FFF0;}

  </style>
</head>

<body style="background-color:  #F5FAFF";>
    <div class="row">
      <div class="col-md-1">
      </div>
      <div class="col-md-3">
        <img src="images/FIXOIN.png">
      </div>
      <div class="col-md-4">
        <h1 align="center" style="font-family:colonna MT";><font color="black">SERVICE PORTAL</font></h1>
        <h4 align="center">(Door Step Maintenance Service)</h4>
      </div>
      <div class="col-md-3">
        <h4 class="zyx" align="right"><font color="green"><span><i class="fa fa-phone fa-1x"></i></span></font> +91-9439-48-9095</h4>
         <h4 align="right" class="online-shop">
        <a style="color:#FF0000;" href="http://www.fixoin.in"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Online Store</a>
         </h4>


        <p align="right">
          <a href="http://facebook.com"><img src="images/facebook.png" height="20px" width="20px"></a>
          <a href="http://google.com"><img src="images/google.png" height="20px" width="20px"></a>
          <a href="http://twitter.com"><img src="images/twitter.png" height="20px" width="20px"></a>
          <a href="http://linkedin.com"><img src="images/linkedin.jpg" height="20px" width="20px"></a>
          <a href="http://youtube.com"><img src="images/youtube.png" height="20px" width="20px"></a>
        </p>
      </div>
      <div class="col-md-1">
      </div>
    </div>
   
<div class="hbgh">
<div class="container">
<header id="header">
  <div class="row t-container">
    <div class="span9">
      <nav id="nav" role="navigation">
        <a href="#nav" title="Show navigation">Show navigation</a>
        <a href="#" title="Hide navigation">Hide navigation</a>
          <ul class="clearfix">
            <li><a href="index.php" title="">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="#"><span>Track</span></a>
            <ul> <!-- Submenu -->
              <li><a href="track.php">Ticket No.</a></li>
              <li><a href="searchmob.php">Mobile No.</a></li>   
            </ul> <!-- End Submenu -->      
            </li>                
            <li><a href="http://www.fixoin.in">Online Store</a></li>
            <li><a href="#"><span>Company</span></a>
            <ul> <!-- Submenu -->
              <li><a href="about.php">About</a></li>
              <li><a href="branches.php">Branches</a></li>
              <li><a href="termsandconditions.php">T & C</a></li>
              <li><a href="contact.php">Contact</a></li>  
            </ul>
          </li>
          </ul>
      </nav>
    </div> 
  </div> 
</header>
</div>
</div>
<br/>
<div class="container">
<p align="center" style="font-size:20px;"><font color="maroon">FiXOIN Service is a unit of <a> Alaka Infotech </a>,Baripada,Mayurbhanj,registered under <a> ISO 9001:2015 </a> certified company.<br/>
 FiXOIN is implementing for door step maintenances.In order to provide better and quick services to the public.
 To avail this services the user can raise their complain via online, offline or any sources of communication(Call,SMS,Whats App.). 
 After the complain lodged by the user they will get ticket number and the service provider will reach at their door step for resolving the issue.</font></p>
<br/>
<br/>

</div>
<div class="row" id="sname">
<h3 align="center" style="color:#D35400;"> <u>Our Services</u></h3>
<br/>
<div class="col-md-1">
</div>
<div class="col-md-4">
<h4>Software Services</h4> 
<h4>Hardware services</h4>
<h4>Domain & Hosting </h4>
<h4>Electrical Services</h4>
<h4>Electronics services</h4>
<h4>Event Management</h4>
<h4>Coaching Services</h4>
<h4>Legal Services</h4>
</div>
<div class="col-md-2"></div>
<div class="col-md-4">
<h4>Hotel & Restaurant</h4>
<h4>Tour & Travels</h4>
<h4>Automobile</h4>
<h4>Medical Services</h4>
<h4>Plumbing Services</h4>
<h4>Construction</h4>
<h4>Real Estate</h4>
<h4>Rent Services</h4>
<div class="col-md-1">
</div>
</div>
<br/>
</div>
 
<br/>
<br/>
<h4 align="center">&#169 2018. FIXOIN . All Right Reserved. | Powered by <a href="www.alakainfotech.com">ALAKA INFOTECH.</a></h4>
<script type="text/javascript">
  document.oncontextmenu = document.body.oncontextmenu = function() {return false;}
</script>

</body>
</html>