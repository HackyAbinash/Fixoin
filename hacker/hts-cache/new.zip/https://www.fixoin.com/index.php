
<!DOCTYPE html>
<html>
<head>
  <title>FiXOIN SERVICE PORTAL</title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
  <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
  <link rel="icon" href="images/x.ico" sizes="100x200" type="image/ico">
  <link rel="stylesheet" type="text/css" href="css/front.css" />
  <link rel="stylesheet" href="css/style.css" type="text/css">
  <link rel="stylesheet" href="nav/css/styles.css" type="text/css">
  <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
  <link rel="stylesheet" href="font/css/font-awesome.min.css" type="text/css">
 
        <link href='http://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css' />
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.6.4/jquery.min.js"></script>
  <!-- Latest compiled and minified JavaScript -->
  <script src="js/bootstrap.min.js"></script>
 
  <style type="text/css">
.online-shop {
  animation: blinker 1s linear infinite;
}

@keyframes blinker {  
  20% { opacity: 0; }
}
.online-shop:hover {
  animation:none;
}
  </style>

</head>
<body style="background-color:  #F5FAFF";>
  <button onclick="topFunction()" id="myBtn" title="Go to top"><span><i class="fa fa-angle-double-up fa-2x"></i></span></button>
    <div class="row">
      <div class="col-md-1">
      </div>
      <div class="col-md-3">
        <img src="images/FIXOIN.png">
       </div>
      <div class="col-md-4">
        <h1 align="center" style="font-family:colonna MT";><font color="black">SERVICE PORTAL</font></h1>
        <h4 align="center">(Door Step Maintenance Service)</h4>
      </div>
      <div class="col-md-3">
        <h4 class="zyx" align="right"><font color="green"><span><i class="fa fa-phone fa-1x"></i></span></font> +91-9439-48-9095</h4>
         <h4 align="right" class="online-shop" >
        <a style="color:#FF0000;" href="http://www.fixoin.in" target="_blank"><i class="fa fa-shopping-cart" aria-hidden="true"></i> Online Store</a>
         </h4>


        <p align="right">
          <a href="http://facebook.com"><img src="images/facebook.png" height="20px" width="20px"></a>
          <a href="http://google.com"><img src="images/google.png" height="20px" width="20px"></a>
          <a href="http://twitter.com"><img src="images/twitter.png" height="20px" width="20px"></a>
          <a href="http://linkedin.com"><img src="images/linkedin.jpg" height="20px" width="20px"></a>
          <a href="http://youtube.com"><img src="images/youtube.png" height="20px" width="20px"></a>
        </p>
      </div>
      <div class="col-md-1">
      </div>
    </div>
<div class="hbgh">
<div class="container">
<header id="header">
  <div class="row t-container">
    <div class="span9">
      <nav id="nav" role="navigation">
        <a href="#nav" title="Show navigation">Show navigation</a>
        <a href="#" title="Hide navigation">Hide navigation</a>
          <ul class="clearfix">
            <li class="active"><a href="index.php" title="">Home</a></li>
            <li><a href="register.php">Register</a></li>
            <li><a href="#"><span>Track</span></a>
            <ul> <!-- Submenu -->
              <li><a href="track.php">Ticket No.</a></li>
              <li><a href="searchmob.php">Mobile No.</a></li>   
            </ul> <!-- End Submenu -->      
            </li>                
            <li><a href="http://www.fixoin.in">Online Store</a></li>
            <li><a href="#"><span>Company</span></a>
            <ul> <!-- Submenu -->
              <li><a href="about.php">About</a></li>
              <li><a href="branches.php">Branches</a></li>
              <li><a href="termsandconditions.php">T & C</a></li>
              <li><a href="contact.php">Contact</a></li>   
            </ul>
          </li>
          </ul>
      </nav>
    </div> 
  </div> 
</header>
</div>
</div>
<br/>
  <div class="row">
    <div class="col-md-1">
    </div>
    <div class="col-md-10" align="center"> 
     
        <a href="https://fixoinfood.com/">
        <h4><img src="images/blinking_new.gif"><font color="#CC0000">Fixoin Food Delivery</font></h4>
        </a>
     
</div></div>
            <div class="main" align="center">
                <!-- FIFTH EXAMPLE -->
                <div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/software.jpg" /></a>
                    <div class="mask">
                        <h2>Software Services</h2>
                        <p>You Can ask for any type of Software Related Problems, Development, Inquiry, Support, etc..</p>
                        <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
                <div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/hardware.jpg" /></a>
                    <div class="mask">
                        <h2>Hardware Services</h2>
                        <p>You Can ask for any type of Hardware Related Problems,Like Laptop,PC, CCTV, Printer  etc..</p>
                       <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
                <div class="view view-fifth">
                <a href="https://www.qintov.com" target="_blank">
                    <img src="images/domain.jpg" /></a>
                    <div class="mask">
                        <h2>Domain & Hosting</h2>
                        <p>You Can Register or apply for maintenance of your Domain Name and Hosting Like Shared,VPS,Cloud etc..</p>
                        <a href="https://www.qintov.com" target="_blank" class="info">Register Now</a>
                    </div>
                </div>
                <div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/electrical.jpg" /></a>
                    <div class="mask">
                        <h2>Electrical Services</h2>
                        <p>You Can ask for any type of Electrical Related Problems,Like Wiring,Motor, Generator,cooler,grinder Repairing, etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>


                <div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/beautyandspa.png" /></a>
                    <div class="mask">
                        <h2>Beauty & SPA</h2>
                        <p>Get beautician for Female and Male at your door step.</p>
                        <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
                <div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/pujasamagri.png" /></a>
                    <div class="mask">
                        <h2>Puja Samagri</h2>
                        <p>You will get Puja Samagri and Brahman at your door step </p>
                       <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
                <div class="view view-fifth">
                <a href="https://www.qintov.com" target="_blank">
                    <img src="images/astrology.png" /></a>
                    <div class="mask">
                        <h2>Astrology</h2>
                        <p>Astrology Service, Jatak , Bastu..etc. </p>
                        <a href="https://www.qintov.com" target="_blank" class="info">Register Now</a>
                    </div>
                </div>
                <div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/event.jpg" /></a>
                    <div class="mask">
                        <h2>Event Management</h2>
                        <p>You Can ask for any type of Event Management Query ,Marriage, Puja decoration, Birthday  etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>


				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/electronics.jpg" /></a>
                    <div class="mask">
                        <h2>Electronics Services</h2>
                        <p>You Can ask for any type of Electronics Related Problems,Like Mobile,TV, Music System  Repairing, Maintenance, Replacement, etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/construction.jpg" /></a>
                    <div class="mask">
                        <h2>Construction</h2>
                        <p>You Can ask for any type of Construction Related Query,Putty ,tiles & marbel etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/plumbing.jpg" /></a>
                    <div class="mask">
                        <h2>Plumbing Services</h2>
                        <p>You Can ask for any type of Plumbing Related Problems, Bathroom Fitting, Repairing, Replacement, etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/waterpurifier.png" /></a>
                    <div class="mask">
                        <h2>Water Filter Service</h2>
                        <p> Water Filter/Purifier Service ,Aquaguard Service etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/tour.jpg" /></a>
                    <div class="mask">
                        <h2>Tour & Travels</h2>
                        <p>You Can ask for any type of Tour Related Query, Private Trip, Family Trip,Picnic etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/hotel.jpg" /></a>
                    <div class="mask">
                        <h2>Hotel & Restaurant</h2>
                        <p>You Can ask for any type of Hotel & Restaurant Related Query,Room Booking, Meal Deliver, etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/automobile.jpg" /></a>
                    <div class="mask">
                        <h2>Automobile</h2>
                        <p>You Can ask for any type of Automobile Related Problems, Repairing, Servicing, Replacement, Excluding ECU Work on Cars etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
				<div class="view view-fifth">
				<a href="http://fixoin.com/register.php">
                    <img src="images/legal.jpg" /></a>
                    <div class="mask">
                        <h2>Legal Services</h2>
                        <p>You Can ask for any type of Legal Advice Like ISO,TAX,LIC,GST etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div><div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/coaching.jpg" /></a>
                    <div class="mask">
                        <h2>Coaching Services</h2>
                        <p>You Can ask for any type of Coaching Related Inquiry, Like Private Tutor, Group, SSC, Banking etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div><div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/medical.jpg" /></a>
                    <div class="mask">
                        <h2>Medical Services</h2>
                        <p>You Can ask for any type of Medical Services,Like Pharmacy, Pathology etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div><div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/real.jpg" /></a>
                    <div class="mask">
                        <h2>Real Estate</h2>
                        <p>You Can ask for any type of Real Estate Work, Plot Buy and Sold etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div><div class="view view-fifth">
                <a href="http://fixoin.com/register.php">
                    <img src="images/rental.jpg" /></a>
                    <div class="mask">
                        <h2>Rental Services</h2>
                        <p>You Can book any type of Rental Services Like Boys Mess, Girls Mess, Room Rent 1BHK, 2BHK, 3BHK etc..</p>
                         <a href="http://fixoin.com/register.php" class="info">Register Now</a>
                    </div>
                </div>
                
            </div>
<br/>
 
<br/>
    <div class="row">
  
      <div class="col-md-3">
       
      </div>
      <div class="col-md-6" align="center">
    
      <div class="fb-page" data-href="https://www.facebook.com/fixoin" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/fixoin" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/fixoin">Fixoin</a></blockquote></div>
      <br/>
      </div>
      <div class="col-md-3">
       
   
      </div>
    </div>
<br/>
<h4 align="center">&#169 2018. FIXOIN . All Right Reserved. | Powered by <a href="http://www.alakainfotech.com" target="_blank">ALAKA INFOTECH.</a></h4>




<script type="text/javascript">
  document.oncontextmenu = document.body.oncontextmenu = function() {return false;}
</script>

<script>
// When the user scrolls down 20px from the top of the document, show the button
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
    if (document.body.scrollTop > 20 || document.documentElement.scrollTop > 20) {
        document.getElementById("myBtn").style.display = "block";
    } else {
        document.getElementById("myBtn").style.display = "none";
    }
}

// When the user clicks on the button, scroll to the top of the document
function topFunction() {
    document.body.scrollTop = 0;
    document.documentElement.scrollTop = 0;
}

function eventclick(){
  alert("Please Call On FiXOIN Number +91-9439489095");
}
</script>


 <script>(function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(d.getElementById(id))return;js=d.createElement(s);js.id=id;js.src="//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.10";fjs.parentNode.insertBefore(js,fjs);}(document,'script','facebook-jssdk'));</script>


</body>
</html>