<br />
<b>Fatal error</b>:  Uncaught Error: Class 'PDO' not found in /home/fixoinco/public_html/include/confign.php:7
Stack trace:
#0 /home/fixoinco/public_html/register.php(2): require_once()
#1 {main}
  thrown in <b>/home/fixoinco/public_html/include/confign.php</b> on line <b>7</b><br />
